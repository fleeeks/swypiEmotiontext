ERROR_CODES = {
    3800: "Need more characters (at least 20-30).",
    5800: "Internal error in swypiEmotionText.",
    6108: "No text detected.",
    2900: "Technical works in progress.",
    4800: "Could not determine emotion."
}