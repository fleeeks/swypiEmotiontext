ERRORS = {
    6108: "No emotion found",
    3800: "Input text is too short (at least 20-30 characters required)",
    5800: "Error processing the text",
    2900: "Maintenance work in progress",
    4800: "Unable to determine the emotion"
}