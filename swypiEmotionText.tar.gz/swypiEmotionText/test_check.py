import json

def text_check(input_text, emotion_check=False):
    # Define emotions directly in the script
    emotions = {
        "happy": ["happy", "joy", "excited", "great", "amazing", "good"],
        "sad": ["sad", "upset", "miserable", "down", "blue"]
    }
    
    # Initialize result
    detected_emotions = []

    # Check if emotion_check is enabled
    if emotion_check:
        for emotion, keywords in emotions.items():
            if any(keyword in input_text.lower() for keyword in keywords):
                detected_emotions.append(emotion)
        
        if detected_emotions:
            return f"Detected emotions: {', '.join(detected_emotions)}"
        else:
            return "No emotions detected"
    else:
        return "Emotion check is disabled"