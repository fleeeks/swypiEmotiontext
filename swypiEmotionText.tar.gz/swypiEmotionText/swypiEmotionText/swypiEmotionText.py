import json

# bd emortions
with open("emotions.json", "r", encoding="utf-8") as file:
    EMOTION_DICT = json.load(file)

# error code
ERROR_CODES = {
    3800: "Need more characters (at least 20-30).",
    5800: "Internal error in swypiEmotionText.",
    6108: "No text detected.",
    2900: "Technical works in progress.",
    4800: "Could not determine emotion."
}

class SwypiEmotionText:
    def __init__(self):
        self.version = "1.0"

    def text_check(self, text: str) -> str:
        """
        SwypiEmotionText
        """
        if not text:
            return self._error(6108)

        if len(text) < 20:
            return self._error(3800)

        emotion = self._detect_emotion(text)
        if emotion:
            return f"swypiEmotionText: {emotion}"
        else:
            return self._error(4800)

    def _detect_emotion(self, text: str) -> str:
        """
        SwypiEmotionText
        """
        for emotion, words in EMOTION_DICT.items():
            if any(word in text.lower() for word in words):
                return emotion
        return None

    def _error(self, code: int) -> str:
        """
        SwypiEmotionText
        """
        return f"swypiEmotionText: I couldn't figure out :( Error code: {code} - {ERROR_CODES[code]}"


if __name__ == "__main__":
    swypi = SwypiEmotionText()
    text = input("Enter text: ")
    print(swypi.text_check(text))