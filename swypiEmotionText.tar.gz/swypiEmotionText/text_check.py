import random

def text_check(input_text):
    # List of possible emotional triggers based on the tone of the input text
    positive_keywords = ['happy', 'great', 'awesome', 'joy', 'excited', 'love', 'good', 'amazing']
    negative_keywords = ['sad', 'upset', 'miserable', 'down', 'bad', 'angry', 'hate']

    # Random sentiment assignment for simplicity (you can replace this with a more advanced model later)
    positive_score = sum(word in input_text.lower() for word in positive_keywords)
    negative_score = sum(word in input_text.lower() for word in negative_keywords)

    # Basic sentiment detection logic
    if positive_score > negative_score:
        return "Emotion detected: Happy"
    elif negative_score > positive_score:
        return "Emotion detected: Sad"
    else:
        return "Emotion detected: Neutral"